/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

import javax.swing.JFrame;
import java.util.*;
import java.io.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author duggal
 */
public class menumdi extends javax.swing.JFrame
{
    public static ArrayList<Member> members;
    public static ArrayList<Category> categorys;
    public static ArrayList<Products> products;
    public static ArrayList<Vendor> vendors;
    public static ArrayList<Transaction> transactions;
    public static ArrayList<Discount> discounts;
    public static ArrayList<Storekeeper> users;
    
    public static void loadusers()
    {
        File f = new File("..//SouvStore//data//Storekeepers.txt");
        try
        {
            users = new ArrayList<>();
            Scanner sc = new Scanner(f);
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                line = line.replace("\n", "").replace("\r", "");
                String []fields = line.split(",");
                String usrname = fields[0];
                String passwd = fields[1];
                Storekeeper obj = new Storekeeper(usrname,passwd);
                users.add(obj);
            }
                        
        }catch(FileNotFoundException e)
         {
             JOptionPane.showMessageDialog(null, "Storekeeper file not found", "MDI Main Menu",JOptionPane.WARNING_MESSAGE);
         }
    }
    
    public static void saveusers() throws IOException
    {
        FileWriter fw = new FileWriter("..//SouvStore//data/Storekeepers.txt");
        for(Storekeeper u : users)
        {
            String line = u.getUser() + "," + u.getPass() + "\n";
            fw.write(line);
        }
        fw.close();
    }
    
    
    public static void loadmembers()
    {
        File f = new File("..//SouvStore//data/Members.txt");
        try
        {
            members = new ArrayList<>();
            Scanner sc = new Scanner(f);
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                line = line.replace("\n", "").replace("\r", "");
                String []fields = line.split(",");
                String memid = fields[0];
                String memname = fields[1];
                int points = Integer.parseInt(fields[2]);
                Member obj = new Member(memid, memname, points);
                members.add(obj);
            }
        }catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Members file not found", "MDI Main Menu",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public static void savemembers() throws IOException
    {
        try (FileWriter fw = new FileWriter("..//SouvStore//data/Members.txt")) 
        {
            
            for(Member m : members)
            {
                String line;
                line = m.getMemberID() + "," + m.getMemberName() + "," +  m.getLoyaltyPoint() + "\n";
                fw.write(line);
            }
            fw.close();
        }
        
    }
    
    public static void loadcategorys()
    {
        File f = new File("..//SouvStore//data/Category.txt");
        try
        {
            categorys = new ArrayList<>();
            Scanner sc = new Scanner(f);
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                line = line.replace("\n", "").replace("\r", "");
                String []fields = line.split(",");
                String catid = fields[0];
                String catname = fields[1];
                int lastno = Integer.parseInt(fields[2]);
                Category obj = new Category(catid, catname, lastno);
                categorys.add(obj);
            }
        }catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Category file not found", "MDI Main Menu",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public static void savecategorys() throws IOException
    {
        FileWriter fw = new FileWriter("..//SouvStore//data/Category.txt");
        for(Category c : categorys)
        {
            String line = c.getCatID() + "," + c.getCatName() + "," + c.getLastNo() + "\n";
            fw.write(line);
        }
        fw.close();
    }
    
    public static void loadproducts()
    {
        File f = new File("..//SouvStore//data/Products.txt");
        try
        {
            products = new ArrayList<>();
            Scanner sc = new Scanner(f);
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                line = line.replace("\n", "").replace("\r", "");
                String []fields = line.split(",");
                String prodid = fields[0];
                String prodname = fields[1];
                String proddescp = fields[2];
                int availqty = Integer.parseInt(fields[3]);
                double price = Double.parseDouble(fields[4]);
                int barno = Integer.parseInt(fields[5]);
                int reordqty = Integer.parseInt(fields[6]);
                int ordqty = Integer.parseInt(fields[7]);
                Products obj = new Products(prodid,prodname,proddescp,availqty,price,barno,reordqty,ordqty);
                products.add(obj);
            }
        }catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Products file not found", "MDI Main Menu",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public static void saveproducts() throws IOException
    {
        FileWriter fw = new FileWriter("..//SouvStore//data/Products.txt");
        for(Products p : products)
        {
            String line = p.getProdID() + "," + p.getProdName() + "," + p.getProdDesc() + "," + p.getQtyAvail() + ","
                    + p.getPrice() + "," + p.getBarcodeNo() + "," + p.getReOrdQty() + "," + p.getOrdQty() + "\n";
            fw.write(line);
        }
        fw.close();
    }
    
    public static void loadvendors()
    {
        File f = new File("..//SouvStore//data/Vendors.txt");
        try
        {
            vendors = new ArrayList<>();
            Scanner sc = new Scanner(f);
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                line = line.replace("\n", "").replace("\r", "");
                String []fields = line.split(",");
                String vendname = fields[0];
                String venddesc = fields[1];
                String vendcatid = fields[2];
                Vendor obj = new Vendor(vendname, venddesc, vendcatid);
                vendors.add(obj);
            }
        }catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Vendors file not found", "MDI Main Menu",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public static void savevendors() throws IOException
    {
        FileWriter fw = new FileWriter("..//SouvStore//data/Vendors.txt");
        for(Vendor v : vendors)
        {
            String line = v.getVendorName() + "," + v.getVendorDesc() + "," + v.getCatID() + "\n";
            fw.write(line);
        }
        fw.close();
    }
    
    public static void loadtransactions()
    {
        File f = new File("..//SouvStore//data/Transactions.txt");
        try
        {
            transactions = new ArrayList<>();
            Scanner sc = new Scanner(f);
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                line = line.replace("\n", "").replace("\r", "");
                String []fields = line.split(",");
                int tranid = Integer.parseInt(fields[0]);
                String prodid = fields[1];
                String memid = fields[2];
                int purqty = Integer.parseInt(fields[3]);
                String pdate = fields[4];
                Transaction obj = new Transaction(tranid,prodid,memid,purqty,pdate);
                transactions.add(obj);
                
            }
        }catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Transactions file not found", "MDI Main Menu",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public static void savetransactions() throws IOException
    {
        FileWriter fw = new FileWriter("..//SouvStore//data/Transactions.txt");
        for(Transaction t : transactions)
        {
            String line = t.getTranID() + "," + t.getProdID() + "," + t.getMemberID() + "," + t.getPurQty() + "," + t.getPurDate() + "\n";
            fw.write(line);
        }
        fw.close();
    }
    
    public static void loaddiscounts()
    {
        File f = new File("..//SouvStore//data/Discounts.txt");
        try
        {
            discounts = new ArrayList<>();
            Scanner sc = new Scanner(f);
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                line = line.replace("\n", "").replace("\r", "");
                String []fields = line.split(",");
                String discode = fields[0];
                String disdesc = fields[1];
                String sdate = fields[2];
                String per = fields[3];
                int disperc = Integer.parseInt(fields[4]);
                String disapp = fields[5];
                Discount obj = new Discount(discode,disdesc,sdate,per,disperc,disapp);
                discounts.add(obj);
            }
        }catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Discounts file not found", "MDI Main Menu",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public static void savediscounts() throws IOException
    {
        FileWriter fw = new FileWriter("..//SouvStore//data/Discounts.txt");
        for(Discount d : discounts)
        {
            String line = d.getDiscountCode() + "," + d.getDesc() + "," + d.getStartDate() + ","
                     + d.getPeriod() + "," + d.getDiscountPercent() + "," + d.getApplicable() + "\n";
            fw.write(line);
        }
        fw.close();
    }
    
    
    
    
    /**
     * Creates new form menumdi
     */
    public menumdi() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        users = new ArrayList<>();
        members = new ArrayList<>();
        categorys = new ArrayList<>();
        products = new ArrayList<>();
        vendors = new ArrayList<>();
        transactions = new ArrayList<>();
        discounts = new ArrayList<>();
        loadusers();
        loadmembers();
        loadcategorys();
        loadproducts();
        loadvendors();
        loadtransactions();
        loaddiscounts();
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mdidsk = new javax.swing.JDesktopPane();
        mdimenubar = new javax.swing.JMenuBar();
        memmenu = new javax.swing.JMenu();
        addmemmenu = new javax.swing.JMenuItem();
        catmenu = new javax.swing.JMenu();
        addcatmenu = new javax.swing.JMenuItem();
        prodmenu = new javax.swing.JMenu();
        addprodmenu = new javax.swing.JMenuItem();
        vendmenu = new javax.swing.JMenu();
        addvendmenu = new javax.swing.JMenuItem();
        tranmenu = new javax.swing.JMenu();
        buyprodmenu = new javax.swing.JMenuItem();
        discmenu = new javax.swing.JMenu();
        adddiscmenu = new javax.swing.JMenuItem();
        stormenu = new javax.swing.JMenu();
        addusermenu = new javax.swing.JMenuItem();
        repomenu = new javax.swing.JMenu();
        showcatmenu = new javax.swing.JMenuItem();
        showprodmenu = new javax.swing.JMenuItem();
        showtranmenu = new javax.swing.JMenuItem();
        showmemmenu = new javax.swing.JMenuItem();
        exitmenu = new javax.swing.JMenu();
        quitmenu = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("University Souvenir Store -  Main Menu");
        setName("menumdifrm"); // NOI18N

        javax.swing.GroupLayout mdidskLayout = new javax.swing.GroupLayout(mdidsk);
        mdidsk.setLayout(mdidskLayout);
        mdidskLayout.setHorizontalGroup(
            mdidskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 899, Short.MAX_VALUE)
        );
        mdidskLayout.setVerticalGroup(
            mdidskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 475, Short.MAX_VALUE)
        );

        memmenu.setText("Members");

        addmemmenu.setText("Add Member");
        addmemmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addmemmenuActionPerformed(evt);
            }
        });
        memmenu.add(addmemmenu);

        mdimenubar.add(memmenu);

        catmenu.setText("Categories");

        addcatmenu.setText("Add Category");
        addcatmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addcatmenuActionPerformed(evt);
            }
        });
        catmenu.add(addcatmenu);

        mdimenubar.add(catmenu);

        prodmenu.setText("Products");

        addprodmenu.setText("Add Product");
        addprodmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addprodmenuActionPerformed(evt);
            }
        });
        prodmenu.add(addprodmenu);

        mdimenubar.add(prodmenu);

        vendmenu.setText("Vendors");

        addvendmenu.setText("Add Vendor");
        addvendmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addvendmenuActionPerformed(evt);
            }
        });
        vendmenu.add(addvendmenu);

        mdimenubar.add(vendmenu);

        tranmenu.setText("Transactions");

        buyprodmenu.setText("Buy Products");
        buyprodmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buyprodmenuActionPerformed(evt);
            }
        });
        tranmenu.add(buyprodmenu);

        mdimenubar.add(tranmenu);

        discmenu.setText("Discounts");

        adddiscmenu.setText("Add Discounts");
        adddiscmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adddiscmenuActionPerformed(evt);
            }
        });
        discmenu.add(adddiscmenu);

        mdimenubar.add(discmenu);

        stormenu.setText("Storekeepers");

        addusermenu.setText("Add Storekeepers");
        addusermenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addusermenuActionPerformed(evt);
            }
        });
        stormenu.add(addusermenu);

        mdimenubar.add(stormenu);

        repomenu.setText("Reports");

        showcatmenu.setText("Show All Categories");
        showcatmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showcatmenuActionPerformed(evt);
            }
        });
        repomenu.add(showcatmenu);

        showprodmenu.setText("Show All Products");
        showprodmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showprodmenuActionPerformed(evt);
            }
        });
        repomenu.add(showprodmenu);

        showtranmenu.setText("Show All Transactions");
        showtranmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showtranmenuActionPerformed(evt);
            }
        });
        repomenu.add(showtranmenu);

        showmemmenu.setText("Show All Members");
        showmemmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showmemmenuActionPerformed(evt);
            }
        });
        repomenu.add(showmemmenu);

        mdimenubar.add(repomenu);

        exitmenu.setText("Exit");
        exitmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitmenuActionPerformed(evt);
            }
        });

        quitmenu.setText("Quit");
        quitmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitmenuActionPerformed(evt);
            }
        });
        exitmenu.add(quitmenu);

        mdimenubar.add(exitmenu);

        setJMenuBar(mdimenubar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mdidsk)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mdidsk)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitmenuActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_exitmenuActionPerformed

    private void addmemmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addmemmenuActionPerformed
        // TODO add your handling code here:
        addmemberfrm f = new addmemberfrm();
        mdidsk.add(f);
        f.setVisible(true);
        
    }//GEN-LAST:event_addmemmenuActionPerformed

    private void quitmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitmenuActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_quitmenuActionPerformed

    private void addcatmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addcatmenuActionPerformed
        // TODO add your handling code here:
        addcategoryfrm f = new addcategoryfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_addcatmenuActionPerformed

    private void addprodmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addprodmenuActionPerformed
        // TODO add your handling code here:
        addproductfrm f = new addproductfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_addprodmenuActionPerformed

    private void addvendmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addvendmenuActionPerformed
        // TODO add your handling code here:
        addvendorfrm f = new addvendorfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_addvendmenuActionPerformed

    private void adddiscmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adddiscmenuActionPerformed
        // TODO add your handling code here:
        adddiscountfrm f = new adddiscountfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_adddiscmenuActionPerformed

    private void addusermenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addusermenuActionPerformed
        // TODO add your handling code here:
        adduserfrm f = new adduserfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_addusermenuActionPerformed

    private void showcatmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showcatmenuActionPerformed
        // TODO add your handling code here:
        showcategoryfrm f = new showcategoryfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_showcatmenuActionPerformed

    private void showprodmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showprodmenuActionPerformed
        // TODO add your handling code here:
        showproductfrm f = new showproductfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_showprodmenuActionPerformed

    private void showmemmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showmemmenuActionPerformed
        // TODO add your handling code here:
        showmemberfrm f = new showmemberfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_showmemmenuActionPerformed

    private void showtranmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showtranmenuActionPerformed
        // TODO add your handling code here:
        showtransfrm f = new showtransfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_showtranmenuActionPerformed

    private void buyprodmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buyprodmenuActionPerformed
        // TODO add your handling code here:
        buyproductfrm f = new buyproductfrm();
        mdidsk.add(f);
        f.setVisible(true);
    }//GEN-LAST:event_buyprodmenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menumdi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menumdi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menumdi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menumdi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menumdi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem addcatmenu;
    private javax.swing.JMenuItem adddiscmenu;
    private javax.swing.JMenuItem addmemmenu;
    private javax.swing.JMenuItem addprodmenu;
    private javax.swing.JMenuItem addusermenu;
    private javax.swing.JMenuItem addvendmenu;
    private javax.swing.JMenuItem buyprodmenu;
    private javax.swing.JMenu catmenu;
    private javax.swing.JMenu discmenu;
    private javax.swing.JMenu exitmenu;
    private javax.swing.JDesktopPane mdidsk;
    private javax.swing.JMenuBar mdimenubar;
    private javax.swing.JMenu memmenu;
    private javax.swing.JMenu prodmenu;
    private javax.swing.JMenuItem quitmenu;
    private javax.swing.JMenu repomenu;
    private javax.swing.JMenuItem showcatmenu;
    private javax.swing.JMenuItem showmemmenu;
    private javax.swing.JMenuItem showprodmenu;
    private javax.swing.JMenuItem showtranmenu;
    private javax.swing.JMenu stormenu;
    private javax.swing.JMenu tranmenu;
    private javax.swing.JMenu vendmenu;
    // End of variables declaration//GEN-END:variables
}
