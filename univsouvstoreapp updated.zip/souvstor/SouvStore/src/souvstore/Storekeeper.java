/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

/**
 *
 * @author duggal
 */
public class Storekeeper 
{
    private String username;
    private String password;
    
    public Storekeeper(String username, String password)
    {
        this.username = username;
        this.password = password;
    }
    
    public String getUser()
    {
        return username;
    }
    
    public void setUser(String username)
    {
        this.username = username;
    }
    
    public String getPass()
    {
        return password;
    }
    
    public void setPass(String password)
    {
        this.password = password;
    }
    
    @Override
    public String toString()
    {
        return "User Name : " + username + "\n" + "Password : " + password;
    }
    
}
