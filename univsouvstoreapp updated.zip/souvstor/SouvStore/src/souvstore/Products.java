/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

/**
 *
 * @author duggal
 */
public class Products 
{
    private String prodID;
    private String prodName;
    private String prodDesc;
    private int qtyAvail;
    private double price;
    private int barcodeNo;
    private int reOrdQty;
    private int ordQty;
    
    public Products(String prodID, String prodName, String prodDesc, int qtyAvail, double price, int barcodeNo, int reOrdQty,int ordQty)
    {
        this.prodID = prodID;
        this.prodName = prodName;
        this.prodDesc = prodDesc;
        this.qtyAvail = qtyAvail;
        this.price = price;
        this.barcodeNo = barcodeNo;
        this.reOrdQty = reOrdQty;
        this.ordQty = ordQty;
    }
    
    public String getProdID()
    {
        return prodID;
    }
    
    public String getProdName()
    {
        return prodName;
    }
    
    public void setProdName(String prodName)
    {
        this.prodName = prodName;
    }
    
    public String getProdDesc()
    {
        return prodDesc;
    }
    
    public void setProdDesc(String prodDesc)
    {
        this.prodDesc = prodDesc;
    }
    
    public int getQtyAvail()
    {
        return qtyAvail;
    }
    
    public void setQtyAvail(int qtyAvail)
    {
        this.qtyAvail = qtyAvail;
    }
    
    public double getPrice()
    {
        return price;
    }
    
    public void setPrice(double price)
    {
        this.price = price;
    }
    
    public int getBarcodeNo()
    {
        return barcodeNo;
    }
    
    public void setBarcodeNo(int barcodeNo)
    {
        this.barcodeNo = barcodeNo;
    }
    
    public int getReOrdQty()
    {
        return reOrdQty;
    }
    
    public void setReOrdQty(int reOrdQty)
    {
        this.reOrdQty = reOrdQty;
    }
    
    public int getOrdQty()
    {
        return ordQty;
    }
    
    public void setOrdQty(int ordQty)
    {
        this.ordQty = ordQty;
    }
    
    @Override
    public String toString()
    {
        return "Product ID          : " + prodID + "\n"
             + "Product Name        : " + prodName  + "\n"
             + "Product Description : " + prodDesc + "\n"
             + "Available Quantity  : " + qtyAvail + "\n"
             + "Price               : " + price + "\n"
             + "Bar Code No.        : " + barcodeNo + "\n"
             + "Re-Order Quantity   : " + reOrdQty + "\n"
             + "Order Quantity      : " + ordQty + "\n";  
    }
}
