/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

/**
 *
 * @author duggal
 */
public class Member 
{
    private String memberID;
    private String memberName;
    private int loyaltyPoint;
    
    public Member(String memberID, String memberName, int loyaltyPoint)
    {
        this.memberID = memberID;
        this.memberName = memberName;
        this.loyaltyPoint = loyaltyPoint;
    }
    
    public String getMemberID()
    {
        return memberID;
    }
    
    public void setMemberID(String memberID)
    {
        this.memberID = memberID;
    }
    
    public String getMemberName()
    {
        return memberName;
    }
    
    public void setMemberName(String memberName)
    {
        this.memberName = memberName;
    }
    
    public int getLoyaltyPoint()
    {
        return loyaltyPoint;
    }
    
    public void setLoyaltyPoint(int loyaltyPoint)
    {
        
        this.loyaltyPoint = loyaltyPoint;
       
    }
    
    @Override
    public String toString()
    {
        return "Member ID     : " + memberID + "\n"
             + "Member Name   : " + memberName + "\n"
             + "Loyalty Point : " + loyaltyPoint + "\n";  
    }
}
