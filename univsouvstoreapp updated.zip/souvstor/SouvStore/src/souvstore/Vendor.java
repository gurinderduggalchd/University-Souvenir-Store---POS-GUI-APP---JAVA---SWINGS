/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

/**
 *
 * @author duggal
 */
public class Vendor 
{
    private String vendorName;
    private String vendorDesc;
    private String catID;
    
    public Vendor(String vendorName, String vendorDesc, String catID)
    {
        this.vendorName = vendorName;
        this.vendorDesc = vendorDesc;
        this.catID = catID;
    }
    
    public String getVendorName()
    {
        return vendorName;
    }
    
    public void setVendorName(String vendorName)
    {
        this.vendorName = vendorName;
    }
    
    public String getVendorDesc()
    {
        return vendorDesc;
    }
    
    public void setVendorDesc(String vendorDesc)
    {
        this.vendorDesc = vendorDesc;
    }
    
    public String getCatID()
    {
        return catID;
    }
    
    public void setCatID(String catID)
    {
        this.catID = catID;
    }
    
    
    @Override
    public String toString()
    {
        return  "Vendor Name        : " + vendorName + "\n"
              + "Vendor Description : " + vendorDesc + "\n"
              + "Category ID        : " + catID + "\n"; 
    }
}
