/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

/**
 *
 * @author duggal
 */



public class Category 
{
    private String catID;
    private String catName;
    private int lastNo;
    
    public Category(String catID, String catName, int lastno)
    {
        this.catID = catID;
        this.catName = catName;
        this.lastNo = lastno;
    }
    
    public Category(String catID, String catName)
    {
        this.catID = catID;
        this.catName = catName;
        this.lastNo = 0;
    }
    
    public String getCatID()
    {
        return catID;
    }
    
    public void setCatID(String catID)
    {
        this.catID = catID;
    }
    
    public String getCatName()
    {
        return catName;
    }
    
    public void setCatName(String catName)
    {
        this.catName = catName;
    }
    
    public int getLastNo()
    {
        return lastNo;
    }
    
    public void setLastNo(int lastNo)
    {
        this.lastNo = lastNo;
    }
    
    @Override
    public String toString()
    {
        return "Category ID : " + catID + "  " + "Category Name : " + catName;
    }
    
    
    
    
}
