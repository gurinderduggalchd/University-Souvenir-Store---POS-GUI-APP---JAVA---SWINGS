/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

/**
 *
 * @author duggal
 */
public class Discount 
{
    private String discountCode;
    private String desc;
    private String startDate;
    private String period;
    private int discountPercent;
    private String applicable;
    
    public Discount(String discountCode, String desc, String startDate, String period, int discountPercent, String applicable)
    {
        this.discountCode = discountCode;
        this.desc = desc;
        this.startDate = startDate;
        this.period = period;
        this.discountPercent = discountPercent;
        this.applicable = applicable;
    }
    
    public String getDiscountCode()
    {
        return discountCode;
    }
    
    public void setDiscountCode(String discountCode)
    {
        this.discountCode = discountCode;
    }
    
    public String getDesc()
    {
        return desc;
    }
    
    public void setDesc(String desc)
    {
        this.desc = desc;
    }
    
    public String getStartDate()
    {
        return startDate;
    }
    
    public void setStartDate(String startDate)
    {
        this.startDate = startDate;
    }
    
    public String getPeriod()
    {
        return period;
    }
    
    public void setPeriod(String period)
    {
        this.period = period;
    }
    
    public int getDiscountPercent()
    {
        return discountPercent;
    }
    
    public void setDiscountPercent(int discountPercent)
    {
        this.discountPercent = discountPercent;
    }
    
    public String getApplicable()
    {
        return applicable;
    }
    
    public void setApplicable(String applicable)
    {
        this.applicable = applicable;
    }
    
    @Override
    public String toString()
    {
        return "Discount Code       : " + discountCode + "\n"
             + "Description         : " + desc + "\n"
             + "Start Date          : " + startDate + "\n"
             + "Period              : " + period + "\n"
             + "Discount Percentage : " + discountPercent + "% \n"
             + "Applicable for      : " + applicable + "\n" ;  
    }
}
