/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package souvstore;

/**
 *
 * @author duggal
 */
public class Transaction 
{
    private int tranID;
    private String prodID;
    private String memberID;
    private int purQty;
    private String pdate;
    
    public Transaction(int tranID, String prodID, String memberID, int purQty, String pdate)
    {
        this.tranID = tranID;
        this.prodID = prodID;
        this.memberID = memberID;
        this.purQty = purQty;
        this.pdate = pdate;
    }
    
    public int getTranID()
    {
        return tranID;
    }
    
    public String getProdID()
    {
        return prodID;
    }
    
    public void setProdID(String prodID)
    {
        this.prodID = prodID;
    }
    
    public String getMemberID()
    {
        return memberID;
    }
    
    public void setMemberID(String memberID)
    {
        this.memberID = memberID;
    }
    
    public int getPurQty()
    {
        return purQty;
    }
    
    public void setPurQty(int purQty)
    {
        this.purQty = purQty;
    }
    
    public String getPurDate()
    {
        return pdate;
    }
    
    public void setPurDate(String pdate)
    {
        this.pdate = pdate;
    }
   
    @Override
    public String toString()
    {
        return "Transaction ID     : " + tranID + "\n"
             + "Product ID         : " + prodID + "\n"
             + "Member ID          : " + memberID + "\n"
             + "Purchased Quantity : " + purQty + "\n"
             + "Date               : " + pdate + "\n";   
    }
}
